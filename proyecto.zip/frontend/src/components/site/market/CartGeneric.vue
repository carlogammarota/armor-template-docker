<template>
  <div>
    <div class="md:w-12/12 lg:pr-10 p-4">
      <div
        class="w-full mx-auto text-gray-800 font-light mb-6 border-b border-gray-200 pb-6"
        v-for="(item, index) in cartItems"
        :key="index"
      >
        <div class="w-full flex items-center mt-2">
          <div class="overflow-hidden rounded-lg w-16 h-16 bg-gray-50 border border-gray-200">
            <div
              v-if="item.product.images"
              class="w-24 h-24"
              :style="'background-image: url(' + item.product.images[0] + ');'"
              style="background-size: 100%"
            ></div>
          </div>
          <div class="flex-grow pl-3 ">
            <h6 class="font-semibold uppercase text-gray-600">
              {{ item.product.title }}
            </h6>
            <p class="text-gray-400 text-sm">
              {{ item.quantity }}
              <div class="w-24">
                <FormKit
                  type="number"
                  label="Cantidad"
                  name="quantity"
                  :value="item.quantity"
                  step="1"
                  @change="updateQuantity({
                    product: item.product._id,
                    quantity: +$event.target.value,
                  })"
                />
              </div>
            </p>
          </div>
          <div>
            <span class="font-semibold text-gray-600 text-2xl">${{ item.product.price }}</span>
          </div>
          <div>
            <button
              class="text-white hover:text-red-600 focus:outline-none ml-2"
              @click="deleteItem(item.product)"
            >
              <i class="fa-solid fa-trash m-auto" style="font-size: 12px"></i>
            </button>
          </div>
        </div>
      </div>

      <div class="mb-6 pb-6 border-b border-gray-200" v-if="$route.path == '/products/checkout'">
        <div class="-mx-2 flex items-end justify-end">
          <div class="flex-grow px-2 lg:max-w-xs">
            <label class="text-gray-600 font-semibold text-sm mb-2 ml-1">Discount code</label>
            <div>
              <input
                class="w-full px-3 py-2 border border-gray-200 rounded-md focus:outline-none focus:border-indigo-500 transition-colors"
                placeholder="XXXXXX"
                type="text"
              />
            </div>
          </div>
          <div class="px-2">
            <button
              class="block w-full max-w-xs mx-auto border border-transparent bg-gray-400 hover:bg-gray-500 focus:bg-gray-500 text-white rounded-md px-5 py-2 font-semibold"
            >
              APPLY
            </button>
          </div>
        </div>
      </div>

      <div class="mb-6 pb-6 border-b border-gray-200 text-gray-800">
        <div class="w-full flex mb-3 items-center">
          <div class="flex-grow">
            <span class="text-gray-600">Subtotal</span>
          </div>
          <div class="pl-3">
            <span class="font-semibold">${{ subtotal.toFixed(2) }}</span>
          </div>
        </div>
        <div class="w-full flex items-center">
          <div class="flex-grow">
            <span class="text-gray-600">Taxes</span>
          </div>
          <div class="pl-3">
            <span class="font-semibold">${{ taxes.toFixed(2) }}</span>
          </div>
        </div>
      </div>

      <div class="mb-6 pb-6 border-b border-gray-200 md:border-none text-gray-800 text-xl">
        <div class="w-full flex items-center">
          <div class="flex-grow">
            <span class="text-gray-600">Total</span>
          </div>
          <div class="pl-3">
            <span class="font-semibold text-gray-400 text-sm mr-2">USD</span>
            <span class="font-semibold">${{ total.toFixed(2) }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';

export default {
  computed: {
    ...mapGetters(['cartItems', 'cartMenu']),
    subtotal() {
      return this.cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
    },
    taxes() {
      return this.subtotal * 0.10; // assuming a 10% tax rate
    },
    total() {
      return this.subtotal + this.taxes;
    }
  },
  methods: {
    ...mapActions(['removeFromCart', 'clearCart', 'updateQuantity']),
    deleteItem(item) {
      this.removeFromCart(item);
    },
  },
  components: {},
  watch: {
    cartItems: {
      handler() {
        this.$store.dispatch('updateCartMenu');
      },
      deep: true,
    },
  },
};
</script>

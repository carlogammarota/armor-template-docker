<template>
    <div>
    create category events</div>
</template>
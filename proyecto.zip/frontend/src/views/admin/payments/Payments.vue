<!-- Modelo para crear una vista nueva dentro de admin -->
<template>
  <div>
    <div>
      <AdminHeader
        :title="$t('payments')"
        icon="fa-solid fa-star"
      ></AdminHeader>

      <div class="overflow-x-auto">
      <div class="overflow-x-auto">
  <table class="table">
    <!-- head -->
    <thead>
      <tr>
        <!-- <th>
          <label>
            <input type="checkbox" class="checkbox" />
          </label>
        </th> -->
        <th>Email</th>
        <th>Products</th>
        <th>Status</th>
        <th>Price Total</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr v-for="payment in payments" :key="payment.index">
        <!-- <th>
          <label>
            <input type="checkbox" class="checkbox" />
          </label>
        </th> -->
        <!-- {{payment}} -->
        <td>
          <div class="flex items-center gap-3">
            <div class="avatar">
              <div class="mask mask-squircle w-12 h-12">
                <!-- <img :src="producto.images" v-for="producto in payment.productos" alt="Avatar Tailwind CSS Component" /> -->
              </div>
            </div>
            <div>
              <div class="font-bold" v-if="payment.fullname">{{payment.fullname}}</div>
              <!-- <div class="font-bold" else>no tiene nombre</div> -->

              <div class="text-sm opacity-50">{{payment.email}}</div>
            </div>
          </div>
        </td>
        <td>
          <div v-for="producto in payment.productos" :key="producto.index">
            <div class="flex items-center gap-3">
              <div class="avatar">
                <div class="mask mask-squircle w-12 h-12 my-2">
                  <img :src="producto.image" alt="Avatar Tailwind CSS Component" />
                </div>
              </div>
              <!-- {{producto}} -->
              <div>
                <div class="font-bold">{{producto.title}}</div>
                <div class="font-bold">x{{producto.cantidad}}</div>
                <div class="text-sm opacity-50">$ {{producto.price}}</div> 
              </div>
            </div>

          </div>
          <br/>
          <span class="badge badge-ghost badge-sm bg-black text-white">{{payment.updatedAt}}</span>
        </td>
        <td>
          <!-- mostrar el estado del pago es payment.estado  -->
          <span class="text-green-500 bg-black p-2 rounded" v-if="payment.estado === 'aprobado'">Aprobado</span>
          <span class="text-red-500 bg-black p-2 rounded" v-else-if="payment.estado === 'rechazado'">Rechazado</span>
          <span class="text-yellow-500 bg-black p-2 rounded" v-else-if="payment.estado === 'pendiente'">Pendiente</span>

        </td>
        <td>$ {{payment.total}}</td>
        <th>
          <button class="btn btn-ghost btn-xs">details</button>
        </th>
      </tr>
    </tbody>
    <!-- foot -->
    <!-- <tfoot>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
        <th></th>
      </tr>
    </tfoot> -->
    
  </table>
</div>
      </div>
    </div>
  </div>
</template>
<script>
  import { mapActions, mapGetters } from 'vuex';
  // import BreadCrumbs from '@/components/admin/Breadcrumbs.vue';
  import AdminHeader from '@/components/admin/AdminHeader.vue';
  import FeathersClient from '@/FeathersClient';

  export default {
    //logout
    // name: "AdminDashboard",
    layout: 'AdminLayout',
    data() {
      return {
        payments: [],
      };
    },
    methods: {
      async getPayments() {
        try {
          const payments = await FeathersClient.service('payments').find({
            query: {
              $sort: { createdAt: -1 },
              $limit: 50,
            },
          });
          this.payments = payments.data;
          

          /* 
                        "productos": [ { "id": "6504dbbcd0c09c9b7db7fda9", "cantidad": 10, "precio": 100 } ],
                        asi es el modelo de producto necesito esta en this.payments.productos necesito traer cada producto
                        y agregarselo a payments

                    */

              //en payment.productos_data guardar el producto completo 

              for (let i = 0; i < this.payments.length; i++) {
                const payment = this.payments[i];
                for (let j = 0; j < payment.productos.length; j++) {
                  const producto = payment.productos[j];
                  const producto_data = await FeathersClient.service('products').get(producto.id);
                  payment.productos[j].images = producto_data.images;
                  // payment.productos[j].name = producto_data.name;
                  payment.productos[j].price = producto_data.price;
                  payment.productos[j].title = producto_data.title;

                  //si no tiene imagen agregar una random
                  // if (producto_data.images.length == 0) {
                    payment.productos[j].image = producto_data.images[0] || 'https://via.placeholder.com/150';
                  // }
                  
                  //title
                }
              }

          console.log(payments);
        } catch (error) {
          console.log(error);
        }
      },
    },
    components: {
      // BreadCrumbs,
      AdminHeader,
    },
    mounted() {
      this.getPayments();
    },
  };
</script>
<style></style>

<template>
  <div class="bg-gray-50 py-5 mx-0 lg:mx-24">
    <!-- {{ cartItems }} -->
    <!-- {{cartItems}} -->
    <!-- {{cartItems}} -->
    <div class="px-5">
      <div class="mb-2">
        <router-link
          to="/products"
          href="#"
          class="focus:outline-none hover:underline text-gray-500 text-sm"
          ><i class="mdi mdi-arrow-left text-gray-400"></i>Back</router-link
        >
      </div>
      <div class="mb-2">
        <h1 class="text-3xl md:text-5xl font-bold text-gray-600">Checkout.</h1>
      </div>
      <div class="mb-5 text-gray-400">
        <a href="#" class="focus:outline-none hover:underline text-gray-500"
          >Home</a
        >
        <router-link
          to="/products/cart"
          class="focus:outline-none hover:underline text-gray-500"
          >Cart</router-link
        >
        / <span class="text-gray-600">Checkout</span>
      </div>
    </div>
    <div
      class="w-full bg-white border-t border-b border-gray-200 px-5 py-10 text-gray-800"
    >
      <div v-if="cartItems.length == 0" class="text-center">
        <h1 class="text-2xl font-bold text-gray-600">No items in cart</h1>
        <!-- Go to market -->
        <router-link
          to="/products"
          class="block w-full max-w-xs mx-auto bg-black hover:bg-indigo-700 hover:text-white focus:bg-indigo-700 text-white rounded-lg px-3 py-2 font-semibold mt-4"
          >Go to Market</router-link
        >
      </div>
      <div class="w-full" v-if="cartItems.length > 0">
        <div class="-mx-3 md:flex items-start">
          <div class="w-full">
            <CartGeneric></CartGeneric>
          </div>
          <div class="px-3 md:w-5/12">
            <div
              class="w-full mx-auto rounded-lg bg-white border border-gray-200 p-3 text-gray-800 font-light mb-6 p-8"
            >
              <div class="w-full flex mb-3 items-center">
                <div class="w-32">
                  <span class="text-gray-600 font-semibold">Contact</span>
                </div>
                <div class="flex-grow pl-3">
                  <img
                    src="@/assets/AuthLogo.svg"
                    class="w-6 float-left mr-2"
                  />
                  <span>Armor Template</span>
                </div>
              </div>
              <div class="w-full flex items-center">
                <div class="w-32">
                  <span class="text-gray-600 font-semibold"
                    >Billing Address</span
                  >
                </div>
                <div class="flex-grow pl-3">
                  <span>123 George Street, Sydney, NSW 2000 Australia</span>
                </div>
              </div>
            </div>
            <div
              class="w-full mx-auto rounded-lg bg-white border border-gray-200 p-3 text-gray-800 font-light mb-6"
            >
              <div class="p-4">
              <!-- otro -->
                <FormKit type="form" v-model="datosEnvio">
    <div
      class="px-4 pb-36 md:pt-8 pt-4 lg:pt-16 lg:px-6 lg:col-start-1 lg:row-start-1 lg:px-0 lg:pb-16 lg:border-r lg:border-gray-300"
    >
      <div class="mx-auto max-w-lg lg:max-w-none">
        <section aria-labelledby="contact-info-heading">
          <h2
            id="contact-info-heading"
            class="text-lg font-medium text-gray-900"
          >
            Detalles para el envío
          </h2>

          <!-- Dos columbas -->
          <!-- Imprimir nombre, apellido, telefono y correo electronico -->
          <!-- <div class="mt-3">
          <div class="flex items-start">
            <div class="">
              <p class="text-sm font-medium text-gray-900">Walter Gammarota</p>
              <p class="text-sm text-gray-500">+54 911 5057 1090</p>
              <p class="text-sm text-gray-500">walter@orsai.org</p>
            </div>
          </div>
        </div> -->
          <!-- <div class="relative flex py-3 items-center col-span-2">
          <div class="flex-grow border-t border-gray-400"></div>
          <span class="flex-shrink mx-4 text-xs text-gray-400"
            >Datos de contacto</span
          >
          <div class="flex-grow border-t border-gray-400"></div>
        </div> -->

          <div class="mt-3 grid grid-cols-2 lg:grid-cols-2 lg:gap-x-6 gap-x-2">
            <div>
              <FormKit type="text" name="nombre" label="Nombre" />
            </div>
            <div>
              <FormKit type="text" name="apellido" label="Apellido" />
            </div>
            <div class="col-span-2">
              <FormKit type="email" name="email" label="Correo electrónico" />
            </div>
            <div
              class="col-span-2 flex items-center text-xs"
            >
              <input
                id="same-as-shipping"
                name="same-as-shipping"
                type="checkbox"
                :checked="true"
                class="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
              />
              <div class="ml-3">
                <label
                  for="same-as-shipping"
                  class="font-medium text-gray-900 mb-0"
                  >Voy a retirar mi pedido en la tienda de Orsai</label
                >
                <!-- Div detalle -->
                <div class="mt-0">
                  <p class="text-xs text-gray-500">
                    Paseo la plaza - Local 18 (Av. Corrientes 1660), CABA,
                    Argentina
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section>
          <!-- Divisor con texto centrado "Datos de envío" con HR y centrado -->
          <div class="relative flex py-3 items-center col-span-2">
            <div class="flex-grow border-t border-gray-400"></div>
            <span class="flex-shrink mx-4 text-xs text-gray-400"
              >Datos de envío</span
            >
            <div class="flex-grow border-t border-gray-400"></div>
          </div>

          <div class="sm:col-span-2">
            <!-- <FormKit
              type="direccion"
              class="box-shadow-none"
              style="box-shadow: none"
            /> -->
          </div>
        </section>

        <!-- <section
        v-if="!todosProductosDigitales && !retiroEnTienda"
        aria-labelledby="shipping-heading"
        class="mt-3"
      >
        <h2 class="text-md font-medium text-gray-900 mb-2">
          Dirección de entrega
        </h2>
        <div class="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-3">
          <div class="sm:col-span-3">
            <direcciones />
          </div>
        </div>
      </section> -->

        <!-- <section
        v-if="retiroEnTienda"
        class="mt-6"
        aria-labelledby="shipping-heading"
      >
        <div class="rounded-md bg-orange-50 p-4">
          <div class="flex">
            <div class="flex-shrink-0">
              <Lucide
                icon="Info"
                class="h-5 w-5 text-orange-400"
                aria-hidden="true"
              />
            </div>
            <div class="ml-3">
              <h3 class="text-sm font-medium text-orange-800">
                Retiro en tienda
              </h3>
              <div class="mt-2 text-sm text-orange-700">
                <p>
                  Vas a retirar tu pedido en la tienda de Orsai. Nuestros
                  horarios de atención son de lunes a viernes de 10 a 18hs, y
                  los sábados de 10 a 13hs.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section> -->
        <section
          class="mt-6"
          aria-labelledby="shipping-heading"
        >
          <div class="rounded-md bg-orange-50 p-4 border-l-4 border-orange-400">
            <div class="flex">
              <div class="flex-shrink-0">
                <Lucide
                  icon="Home"
                  class="h-5 w-5 text-orange-700"
                  aria-hidden="true"
                />
              </div>
              <div class="ml-3">
                <h3 class="text-sm font-base text-orange-800">
                  Retiro en tienda
                </h3>
                <div class="mt-2 text-sm text-orange-700 font-light">
                  Vas a retirar tu pedido en la tienda de Orsai. Nuestros
                  horarios de atención son de lunes a viernes de 10 a 18hs, y
                  los sábados de 10 a 13hs.
                </div>
              </div>
            </div>
          </div>
        </section>
        <!-- Si todosProductosDigitales, mostrar mensaje -->
        <section  class="mt-6">
          <div class="rounded-md bg-orange-50 p-4">
            <div class="flex">
              <div class="flex-shrink-0">
                <Lucide
                  icon="Info"
                  class="h-5 w-5 text-orange-400"
                  aria-hidden="true"
                />
              </div>
              <div class="ml-3">
                <h3 class="text-sm font-medium text-orange-800">
                  Pedido sin envío físico
                </h3>
                <div class="mt-2 text-sm text-orange-700">
                  <p>
                    Todos los productos de este pedido son digitales, por lo que
                    se te enviarán por correo electrónico.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <div
          class="mt-10 border-t border-gray-200 pt-6 sm:flex sm:items-center sm:justify-between"
        >
          <Button
            variant="primary"
            class="w-full text-sm sm:order-last sm:ml-6 sm:w-auto"
          >
            Siguiente
          </Button>
          <p
            class="mt-4 text-center text-sm text-gray-500 sm:mt-0 sm:text-left font-light"
          >
            En el siguiente paso podés elegir el método de pago.
          </p>
        </div>
      </div>
    </div>
  </FormKit>

                <FormKit
                  type="form"
                  id="registration-example"
                  :form-class="submitted ? 'hide' : 'show'"
                  submit-label="Register"
                  :actions="false"
                  v-model="informacion"
                >
                  <h1 class="text-2xl font-bold mb-2">Info</h1>
                  <p class="text-sm mb-4">
                    You can put any type of element inside a form, not just
                    FormKit inputs (although only FormKit inputs are included
                    with the submission).
                  </p>
                  <!-- <FormKit
                    type="text"
                    name="nombre"
                    label="Nombre Completo"
                    placeholder="Guillermo Torax"
                    help="Cuál es tu nombre?"
                    validation="required"
                  /> -->
                  <FormKit
                    type="text"
                    name="email"
                    label="Tu email"
                    placeholder="jane@ejemplo.com"
                    help="Cuál es tu email?"
                    validation="required|email"
                  />
                  <!-- <div class="double">
      <FormKit
        type="password"
        name="password"
        label="Password"
        validation="required|length:6|matches:/[^a-zA-Z]/"
        :validation-messages="{
          matches: 'Please include at least one symbol',
        }"
        placeholder="Your password"
        help="Choose a password"
      />
      <FormKit
        type="password"
        name="password_confirm"
        label="Confirm password"
        placeholder="Confirm password"
        validation="required|confirm"
        help="Confirm your password"
      /> 
    </div> -->

                  <!-- <FormKit type="submit" label="Register" /> -->
                  <pre wrap>{{ value }}</pre>
                </FormKit>
                <div v-if="submitted">
                  <h2 class="text-xl text-green-500">Submission successful!</h2>
                </div>
              </div>
            </div>
            <div
              class="w-full mx-auto rounded-lg bg-white border border-gray-200 text-gray-800 font-light mb-6 p-2"
            >
              <div class="p-4">
                <h1 class="text-2xl font-bold">Pago</h1>
                <!-- informacion -->
                <p class="text-sm mb-4">
                  You can put any type of element inside a form, not just
                  FormKit inputs (although only FormKit inputs are included with
                  the submission).
                </p>
              </div>

              <div class="w-full p-3 border-b border-gray-200">
                <div class="">
                  <label for="type1" class="flex items-center cursor-pointer">
                    <input
                      type="radio"
                      class="form-radio h-5 w-5 text-indigo-500"
                      name="type"
                      id="type1"
                      checked
                      @change="informacion.type = 'mercadopago'"
                    />
                    <!-- <img src="@/assets/cards.png" class="h-6 ml-3" /> -->
                    <img
                      src="https://www.sitepro.com.ar/web/wp-content/uploads/2022/08/Mercado-pago-1024x267.png"
                      class="h-6 ml-4"
                      style="margin-left: 15px"
                    />
                  </label>
                </div>
              </div>
              
              <div class="w-full p-3">
              
                <label for="type2" class="flex items-center cursor-pointer">
                  <input
                    type="radio"
                    class="form-radio h-5 w-5 text-indigo-500"
                    name="type"
                    id="type2"
                    @change="informacion.type = 'efectivo'"
                    value="efectivo"
                  />
                  
                  <img
                    src="https://cdn-icons-png.flaticon.com/512/2331/2331876.png"
                    width="40"
                    class="ml-3"
                  />
                  <span class="ml-2">efectivo</span>
                </label>
              </div>
              <!-- paypal -->
              <!-- <div class="w-full p-3">
                <label for="type2" class="flex items-center cursor-pointer">
                  <input
                    type="radio"
                    class="form-radio h-5 w-5 text-indigo-500"
                    name="type"
                    id="type2"
                  />
                  <img
                    src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg"
                    width="80"
                    class="ml-3"
                  />
                </label>
              </div> -->
            </div>
            <div>
              <button
                @click="payNow(cartItems)"
                class="block w-full max-w-xs mx-auto bg-indigo-500 hover:bg-indigo-700 focus:bg-indigo-700 text-white rounded-lg px-3 py-2 font-semibold"
              >
                <i class="mdi mdi-lock-outline mr-1"></i> PAY NOW
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- cart -->
    </div>
    <div class="p-5">
      <div class="text-center text-gray-400 text-sm">
        <a
          href="https://www.buymeacoffee.com/scottwindon"
          target="_blank"
          class="focus:outline-none underline text-gray-400"
          ><i class="mdi mdi-beer-outline"></i>Buy me a beer</a
        >
        and help support open-resource
      </div>
    </div>
  </div>
</template>
<script>
  import { mapGetters, mapActions } from 'vuex';
  import CartGeneric from '@/components/site/market/CartGeneric.vue';
  import FeathersClient from '@/FeathersClient'; // Import FeathersClient for authentication
  //   import { ref } from 'vue'
  // const submitted = ref(false)
  // const submitHandler = async () => {
  //   // Let's pretend this is an ajax request:
  //   await new Promise((r) => setTimeout(r, 1000))
  //   submitted.value = true
  // }
  export default {
    data() {
      return {
        submitted: false,
        informacion: {
          // nombre: '',
          type: 'mercadopago',
          email: '',
        },
      };
    },
    computed: {
      ...mapGetters(['cartItems', 'cartMenu']),
    },
    methods: {
      ...mapActions(['removeFromCart']),
      deleteItem(item) {
        this.removeFromCart(item);
      },
      async submitHandler() {
        // Let's pretend this is an ajax request:
        await new Promise((r) => setTimeout(r, 1000));
        this.submitted = true;
      },
      async payNow(items) {

        //comprobar que halla email
        if (!this.informacion.email) {
          // alert('Por favor ingrese su email');
          // this.$toast.error('Por favor ingrese su email');
          this.$snotify.error('Ingrese su email', 'Error Email', {
          timeout: 2000,
          showProgressBar: false,
          closeOnClick: false,
          pauseOnHover: true,
        });
          return;
        }


        //guardar la cantidad de productos
        // this.cartItems.map((item) => {
        //   console.log('item', item);
        //   return {
        //     id: item._id,
        //     cantidad: item.cantidad,
        //   };
        // });

        // return 0

      if(this.informacion.type == 'mercadopago'){
          const productos = this.cartItems.map((item) => {
          console.log('item', item);
          return {
            id: item.product._id,
            cantidad: item.product.quantity,
          };
        });
        //
        // console.log('productos', productos);
        // return 0
        try {
          const response = await FeathersClient.service('generar-link').create(
            {
              // email: '
              email: this.informacion.email,
              productos: productos,
              tipo: 'producto',
            },
          );
          console.log('response', response.linkDePago)
          //redirect to payment
          window && window.open(response.linkDePago, '_blank');
        } catch (error) {
          console.log('error', error);
          alert('Error al procesar el pago');
        }
      }
      if(this.informacion.type == 'efectivo'){
        // console.log('efectivo');
        // return 0
        alert('Pago en efectivo a desarrollar');
      }
      },
    },
    components: {
      CartGeneric,
    },
  };
</script>
<style>
  /*
module.exports = {
    plugins: [require('@tailwindcss/forms'),]
};
*/
  .form-radio {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    display: inline-block;
    vertical-align: middle;
    background-origin: border-box;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    flex-shrink: 0;
    border-radius: 100%;
    border-width: 2px;
  }

  .form-radio:checked {
    background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3ccircle cx='8' cy='8' r='3'/%3e%3c/svg%3e");
    border-color: transparent;
    background-color: currentColor;
    background-size: 100% 100%;
    background-position: center;
    background-repeat: no-repeat;
  }

  @media not print {
    .form-radio::-ms-check {
      border-width: 1px;
      color: transparent;
      background: inherit;
      border-color: inherit;
      border-radius: inherit;
    }
  }

  .form-radio:focus {
    outline: none;
  }

  .form-select {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23a0aec0'%3e%3cpath d='M15.3 9.3a1 1 0 0 1 1.4 1.4l-4 4a1 1 0 0 1-1.4 0l-4-4a1 1 0 0 1 1.4-1.4l3.3 3.29 3.3-3.3z'/%3e%3c/svg%3e");
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    background-repeat: no-repeat;
    padding-top: 0.5rem;
    padding-right: 2.5rem;
    padding-bottom: 0.5rem;
    padding-left: 0.75rem;
    font-size: 1rem;
    line-height: 1.5;
    background-position: right 0.5rem center;
    background-size: 1.5em 1.5em;
  }

  .form-select::-ms-expand {
    color: #a0aec0;
    border: none;
  }

  @media not print {
    .form-select::-ms-expand {
      display: none;
    }
  }

  @media print and (-ms-high-contrast: active),
    print and (-ms-high-contrast: none) {
    .form-select {
      padding-right: 0.75rem;
    }
  }
</style>

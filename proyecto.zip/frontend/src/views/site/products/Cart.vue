<template>
  <div class="bg-gray-50 py-8 lg:py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto">
      <div class="mb-6">
        <router-link
          to="/products"
          class="inline-flex items-center text-sm font-medium text-gray-500 hover:text-gray-700"
        >
          <svg class="mr-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
          </svg>
          Back
        </router-link>
      </div>
      
      <h1 class="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-gray-900 mb-4">Cart</h1>
      
      <nav class="flex mb-8" aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-3">
          <li><a href="#" class="text-sm font-medium text-gray-500 hover:text-gray-700">Home</a></li>
          <li>
            <div class="flex items-center">
              <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path></svg>
              <a href="#" class="ml-1 text-sm font-medium text-gray-500 hover:text-gray-700 md:ml-2">Cart</a>
            </div>
          </li>
        </ol>
      </nav>
      
      <div class="bg-white shadow-sm rounded-lg overflow-hidden">
        <div class="px-4 py-8 sm:px-6 lg:px-8">
          <div v-if="cartItems.length === 0" class="text-center">
            <h2 class="mt-2 text-lg font-medium text-gray-900">Your cart is empty</h2>
            <p class="mt-1 text-sm text-gray-500">Start adding some items to your cart.</p>
            <div class="mt-6">
              <router-link
                to="/products"
                class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Go to Market
              </router-link>
            </div>
          </div>
          
          <div v-else>
            <CartGeneric></CartGeneric>
          </div>
        </div>
      </div>
      
      <div class="mt-8 flex justify-center">
        <router-link
          to="/products/checkout"
          class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          <svg class="mr-2 -ml-1 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"></path>
          </svg>
          Checkout
        </router-link>
      </div>
    </div>
    
  </div>
</template>
<script>
  import { mapGetters, mapActions } from 'vuex';
  import CartGeneric from '@/components/site/market/CartGeneric.vue';
  export default {
    data() {},
    computed: {
      ...mapGetters(['cartItems', 'cartMenu']),
    },
    components: {
      CartGeneric,
    },
  };
</script>
<style>
  /*
module.exports = {
    plugins: [require('@tailwindcss/forms'),]
};
*/
  .form-radio {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    display: inline-block;
    vertical-align: middle;
    background-origin: border-box;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    flex-shrink: 0;
    border-radius: 100%;
    border-width: 2px;
  }

  .form-radio:checked {
    background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3ccircle cx='8' cy='8' r='3'/%3e%3c/svg%3e");
    border-color: transparent;
    background-color: currentColor;
    background-size: 100% 100%;
    background-position: center;
    background-repeat: no-repeat;
  }

  @media not print {
    .form-radio::-ms-check {
      border-width: 1px;
      color: transparent;
      background: inherit;
      border-color: inherit;
      border-radius: inherit;
    }
  }

  .form-radio:focus {
    outline: none;
  }

  .form-select {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23a0aec0'%3e%3cpath d='M15.3 9.3a1 1 0 0 1 1.4 1.4l-4 4a1 1 0 0 1-1.4 0l-4-4a1 1 0 0 1 1.4-1.4l3.3 3.29 3.3-3.3z'/%3e%3c/svg%3e");
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    background-repeat: no-repeat;
    padding-top: 0.5rem;
    padding-right: 2.5rem;
    padding-bottom: 0.5rem;
    padding-left: 0.75rem;
    font-size: 1rem;
    line-height: 1.5;
    background-position: right 0.5rem center;
    background-size: 1.5em 1.5em;
  }

  .form-select::-ms-expand {
    color: #a0aec0;
    border: none;
  }

  @media not print {
    .form-select::-ms-expand {
      display: none;
    }
  }

  @media print and (-ms-high-contrast: active),
    print and (-ms-high-contrast: none) {
    .form-select {
      padding-right: 0.75rem;
    }
  }
</style>

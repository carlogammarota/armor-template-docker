<template>
    <div class="about">
        <div class="card w-90 bg-neutral text-neutral-content mx-4">
            <div class="card-body items-center text-center">
                <h2 class="card-title">¿ Como Funciona ?</h2>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident fugit, suscipit libero ullam voluptatum, recusandae rerum, minus ad molestiae consequatur veritatis modi rem. Voluptatem atque iste enim. Non, temporibus enim!</p>
                <div class="card-actions justify-end">
                    <!-- <button class="btn btn-primary">Accept</button>
                    <button class="btn btn-ghost">Deny</button> -->
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    layout: "DefaultLayout",
}
</script>

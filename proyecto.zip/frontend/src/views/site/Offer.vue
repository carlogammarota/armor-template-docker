<template>
  <div>
    <div class="bg-gradient-to-b from-pink-100 to-green-200 py-24">
      <img
        class="w-20 lg:w-28 m-auto"
        src="https://res.cloudinary.com/doznjtpmk/image/upload/v1697505969/admin-web/r29rjankqp82kqd8lhqe.svg"
        loading="lazy"
        alt="microsoft"
      />
      <div class="container m-auto px-6 py-20 md:px-12 lg:px-20">
        <div class="m-auto text-center lg:w-8/12 xl:w-7/12">
          <h2 class="text-2xl text-green-900 font-bold md:text-4xl">
            Create your site and start publishing or selling on our using our
            <span class="text-[#1ddd86]">Armor</span> CMS Model
          </h2>
        </div>
        <div
          class="mt-12 m-auto -space-y-4 items-center justify-center md:flex md:space-y-0 md:-space-x-4 xl:w-10/12"
        >
          <div class="relative z-10 -mx-4 group md:w-6/12 md:mx-0 lg:w-5/12">
            <div
              aria-hidden="true"
              class="absolute top-0 w-full h-full rounded-2xl bg-white shadow-xl transition duration-500 group-hover:scale-105 lg:group-hover:scale-110"
            ></div>
            <div class="relative p-6 space-y-6 lg:p-8">
              <h3 class="text-3xl text-gray-700 font-semibold text-center">
                Discount
              </h3>
              <div>
                <div class="relative flex justify-around">
                  <div class="flex items-end">
                    <span class="text-8xl text-gray-800 font-bold leading-0"
                      >35</span
                    >
                    <div class="pb-2">
                      <span class="block text-2xl text-gray-700 font-bold"
                        >%</span
                      >
                      <span class="block text-xl text-red-500 font-bold"
                        >Off</span
                      >
                    </div>
                  </div>
                </div>
              </div>

              <ul role="list" class="w-max space-y-4 py-6 m-auto text-gray-600">
                <li class="space-x-2">
                  <span class="text-green-500 font-semibold">&check;</span>
                  <span>1 Subdomain</span>
                </li>
                <li class="space-x-2">
                  <span class="text-green-500 font-semibold">&check;</span>
                  <span>Personalization</span>
                </li>
                <li class="space-x-2">
                  <span class="text-green-500 font-semibold">&check;</span>
                  <span>Third Advantage: Donate to Project</span>
                </li>
              </ul>

              <p
                class="flex items-center justify-center space-x-4 text-lg text-gray-600 text-center"
              >
                <span>Support</span>

                <a
                  href="wa.link/3k1b7m"
                  class="flex space-x-2 items-center text-purple-600"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="currentColor"
                    class="w-6"
                    viewBox="0 0 16 16"
                  >
                    <path
                      d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.568 17.568 0 0 0 4.168 6.608 17.569 17.569 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.678.678 0 0 0-.58-.122l-2.19.547a1.745 1.745 0 0 1-1.657-.459L5.482 8.062a1.745 1.745 0 0 1-.46-1.657l.548-2.19a.678.678 0 0 0-.122-.58L3.654 1.328zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z"
                    />
                  </svg>
                  <span class="font-semibold">message</span>
                </a>
              </p>
              <button
                type="submit"
                title="Submit"
                class="block w-full py-3 px-6 text-center rounded-xl transition bg-purple-600 hover:bg-purple-700 active:bg-purple-800 focus:bg-indigo-600"
              >
                <span class="text-white font-semibold text-xl"
                  >Subscribe to Beta
                </span>
              </button>
            </div>
          </div>

          <div class="relative group md:w-6/12 lg:w-7/12">
            <div
              aria-hidden="true"
              class="absolute top-0 w-full h-full rounded-2xl bg-white shadow-lg transition duration-500 group-hover:scale-105"
            ></div>
            <div
              class="relative p-6 pt-16 md:p-8 md:pl-12 md:rounded-r-2xl lg:pl-20 lg:p-16"
            >
              <!-- <img
                class="w-20 lg:w-28 m-auto"
                src="https://res.cloudinary.com/doznjtpmk/image/upload/v1697505969/admin-web/r29rjankqp82kqd8lhqe.svg"
                loading="lazy"
                alt="microsoft"
              /> -->
              <ul role="list" class="space-y-4 py-6 text-gray-600">
                <li class="space-x-2">
                  <span class="text-purple-500 font-semibold">&check;</span>
                  <span>E-commerce Solution</span>
                </li>
                <li class="space-x-2">
                  <span class="text-purple-500 font-semibold">&check;</span>
                  <span>Admin Events & Blog Management</span>
                </li>
                <li class="space-x-2">
                  <span class="text-purple-500 font-semibold">&check;</span>
                  <span>User Management System</span>
                </li>
                <li class="space-x-2">
                  <span class="text-purple-500 font-semibold">&check;</span>
                  <span>Dedicated Support & Customization</span>
                </li>
                <li class="space-x-2">
                  <span class="text-purple-500 font-semibold">&check;</span>
                  <span>Dinamic Meta Data Solutions</span>
                </li>
              </ul>
              <p class="text-gray-700">
                Our platform caters to teams of any size, enabling seamless
                addition or replacement of members as required. Some of the
                prominent companies leveraging our services include:
              </p>
              <!-- <div class="mt-6 justify-between gap-1 md:flex grid">
                <img
                  class="w-12 lg:w-12"
                  src="https://cdn.worldvectorlogo.com/logos/vue-js-1.svg"
                  loading="lazy"
                  alt="airbnb"
                />
                <img
                  class="w-12 lg:w-12"
                  src="https://cdn.worldvectorlogo.com/logos/vitejs.svg"
                  loading="lazy"
                  alt="bissell"
                />
                <img
                  class="w-12 lg:w-12"
                  src="https://cdn.worldvectorlogo.com/logos/tailwindcss.svg"
                  loading="lazy"
                  alt="ge"
                />
                <img
                  class="w-14 lg:w-14"
                  src="https://cdn.worldvectorlogo.com/logos/express-109.svg"
                  loading="lazy"
                  alt="microsoft"
                />
                <br />
                <img
                  class="w-12 lg:w-12"
                  src="https://cdn.worldvectorlogo.com/logos/cloudflare-1.svg"
                  loading="lazy"
                  alt="microsoft"
                />
                <img
                  class="w-12 lg:w-12"
                  src="https://cdn.worldvectorlogo.com/logos/feathersjs.svg"
                  loading="lazy"
                  alt="microsoft"
                />
                <img
                  class="w-12 lg:w-12"
                  src="https://cdn.worldvectorlogo.com/logos/nginx-1.svg"
                  loading="lazy"
                  alt="microsoft"
                />
                <img
                  class="w-12 lg:w-12"
                  src="https://cdn.worldvectorlogo.com/logos/docker.svg"
                  loading="lazy"
                  alt="microsoft"
                />
              </div> -->
            </div>
          </div>
        </div>
      </div>
      <div class="flex items-center justify-center space-x-2 mt-4 flex-wrap">
        <a
          href="https://www.linkedin.com/in/carlo-gammarota-23493b24/"
          class="flex flex-none items-center justify-center rounded-full w-12 h-12 hover:bg-slate-200 transition-all bg-white mt-6 rounded-lg hover:bg-slate-700"
          ><svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <circle
              cx="4.983"
              cy="5.009"
              r="2.188"
              fill="currentColor"
            ></circle>
            <path
              d="M9.237 8.855v12.139h3.769v-6.003c0-1.584.298-3.118 2.262-3.118 1.937 0 1.961 1.811 1.961 3.218v5.904H21v-6.657c0-3.27-.704-5.783-4.526-5.783-1.835 0-3.065 1.007-3.568 1.96h-.051v-1.66H9.237zm-6.142 0H6.87v12.139H3.095z"
              fill="currentColor"
            ></path></svg
        ></a>
        <div class="mt-6 justify-between gap-1 md:flex grid">
          <img
            class="w-12 lg:w-12 m-2 bg-white p-1 rounded-lg"
            src="https://cdn.worldvectorlogo.com/logos/vue-js-1.svg"
            loading="lazy"
            alt="airbnb"
          />
          <img
            class="w-12 lg:w-12 m-2 bg-white p-1 rounded-lg"
            src="https://cdn.worldvectorlogo.com/logos/vitejs.svg"
            loading="lazy"
            alt="bissell"
          />
          <img
            class="w-12 lg:w-12 m-2 bg-white p-1 rounded-lg"
            src="https://cdn.worldvectorlogo.com/logos/tailwindcss.svg"
            loading="lazy"
            alt="ge"
          />
          <img
            class="w-14 lg:w-14 m-2 bg-white p-1 rounded-lg"
            src="https://cdn.worldvectorlogo.com/logos/express-109.svg"
            loading="lazy"
            alt="microsoft"
          />
          <br />
          <img
            class="w-12 lg:w-12 m-2 bg-white p-1 rounded-lg"
            src="https://cdn.worldvectorlogo.com/logos/cloudflare-1.svg"
            loading="lazy"
            alt="microsoft"
          />
          <img
            class="w-12 lg:w-12 m-2 bg-white p-1 rounded-lg"
            src="https://cdn.worldvectorlogo.com/logos/feathersjs.svg"
            loading="lazy"
            alt="microsoft"
          />
          <img
            class="w-12 lg:w-12 m-2 bg-white p-1 rounded-lg"
            src="https://cdn.worldvectorlogo.com/logos/nginx-1.svg"
            loading="lazy"
            alt="microsoft"
          />
          <img
            class="w-12 lg:w-12 m-2 bg-white p-1 rounded-lg"
            src="https://cdn.worldvectorlogo.com/logos/docker.svg"
            loading="lazy"
            alt="microsoft"
          />
        </div>
      </div>
    </div>
  </div>
</template>

const { Service } = require('feathers-mongoose');

exports.EventsCategories = class EventsCategories extends Service {
  
};

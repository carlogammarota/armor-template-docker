const { Service } = require('feathers-mongoose');

exports.Events = class Events extends Service {
  
};

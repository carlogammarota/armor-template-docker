const { Service } = require('feathers-mongoose');

exports.BlogsCategories = class BlogsCategories extends Service {
  
};

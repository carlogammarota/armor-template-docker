const { Service } = require('feathers-mongoose');

exports.Payments = class Payments extends Service {
  
};

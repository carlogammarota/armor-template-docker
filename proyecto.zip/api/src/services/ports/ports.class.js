const { Service } = require('feathers-mongoose');

exports.Ports = class Ports extends Service {
  
};

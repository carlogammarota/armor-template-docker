const { Service } = require('feathers-mongoose');
const axios = require('axios');
exports.Blogs = class Blogs extends Service {
   
};

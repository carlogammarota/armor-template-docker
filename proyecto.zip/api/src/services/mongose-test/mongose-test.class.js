const { Service } = require('feathers-mongoose');

exports.MongoseTest = class MongoseTest extends Service {
  
};

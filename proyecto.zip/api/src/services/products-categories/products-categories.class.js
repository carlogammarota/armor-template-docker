const { Service } = require('feathers-mongoose');

exports.ProductsCategories = class ProductsCategories extends Service {
  
};

const { Service } = require('feathers-mongoose');

exports.Settings = class Settings extends Service {
  
};
